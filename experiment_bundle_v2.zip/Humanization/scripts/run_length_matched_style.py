#!/usr/bin/env python3
"""Repeat the complete style experiment after exact source-paired length control."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

for name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.setdefault(name, "2")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".cache/matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(ROOT / ".cache"))

import pandas as pd
from stylometry.analysis import effect_tables, evaluate, shortlist_features
from stylometry.features import (FEATURE_GROUPS, FEATURE_SCHEMA, LENGTH_SENSITIVE_FEATURES,
                                WIKIPEDIA_FEATURES, extract_records)
from stylometry.length_matching import length_balance, prepare_length_matched_dataset
from stylometry.report import markdown_table, write_report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", type=Path, default=ROOT / "data/raw")
    parser.add_argument("--output", type=Path, default=ROOT / "results_length_matched")
    parser.add_argument("--pairs", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--minimum", type=int, default=90)
    parser.add_argument("--maximum", type=int, default=180)
    parser.add_argument("--target", type=int, default=150)
    parser.add_argument("--bootstrap", type=int, default=500)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--model", default="en_core_web_sm")
    parser.add_argument("--reuse-features", action="store_true")
    args = parser.parse_args()
    started, utc = time.monotonic(), datetime.now(timezone.utc).isoformat()
    out = args.output.resolve()
    if out == (ROOT / "results").resolve() or out == (ROOT / "results_pilot").resolve():
        raise ValueError("Use a separate output directory; previous experiments must be preserved.")
    out.mkdir(parents=True, exist_ok=True)
    print("Preparing source-aligned, exactly word-count-matched sentence prefixes...", flush=True)
    samples, manifest = prepare_length_matched_dataset(
        args.raw_dir, ROOT / "data/length_matched", n_pairs=args.pairs, seed=args.seed,
        minimum=args.minimum, maximum=args.maximum, target=args.target, model=args.model)
    (out / "data_manifest.json").write_text(json.dumps(manifest, indent=2))
    versions = {name: importlib.metadata.version(name) for name in
                ["spacy", "en-core-web-sm", "textstat", "numpy", "pandas", "scipy", "scikit-learn", "nltk"]}
    cache_info = {"sample_sha256": manifest["samples_sha256"], "versions": versions, "model": args.model,
                  "extractor_sha256": hashlib.sha256((ROOT / "stylometry/features.py").read_bytes()).hexdigest(),
                  "schema_sha256": hashlib.sha256(json.dumps(FEATURE_SCHEMA, sort_keys=True).encode()).hexdigest()}
    cache, metadata = out / "features.csv", out / "features_cache.json"
    if args.reuse_features and cache.exists() and metadata.exists():
        if json.loads(metadata.read_text()) != cache_info:
            raise ValueError("Matched feature cache differs from sample/extractor/model; rerun without --reuse-features.")
        df = pd.read_csv(cache)
        print(f"Reusing verified matched cache for {len(df)} texts.", flush=True)
    else:
        print(f"Extracting all fixed spaCy/textstat/MATTR features for {len(samples)} matched texts...", flush=True)
        df = pd.DataFrame(extract_records(samples.to_dict("records"), model=args.model)).drop(columns="text")
        df.to_csv(cache, index=False)
        metadata.write_text(json.dumps(cache_info, indent=2))
    # Check actual feature-extractor counts, not only tokenizer preparation.
    if not df.n_words.eq(df.matched_n_words).all():
        raise RuntimeError("Preparation/extraction lexical word counts disagree; stop rather than claim length balance.")
    by_pair = df.pivot(index="pair_id", columns="label", values="n_words")
    if not by_pair[0].eq(by_pair[1]).all():
        raise RuntimeError("Exact within-source length matching failed.")
    balance = length_balance(df)
    balance.to_csv(out / "length_balance.csv", index=False)
    word_balance = balance[balance.measure == "n_words"]
    if not word_balance.standardized_mean_difference.eq(0).all() or not word_balance.ks_statistic.eq(0).all():
        raise RuntimeError("Word-length distributions are not exactly equal in a reported scope.")
    names = list(FEATURE_SCHEMA)
    (out / "feature_schema.json").write_text(json.dumps({n: {"group": FEATURE_GROUPS[n], "definition": FEATURE_SCHEMA[n]} for n in names}, indent=2))
    df[names].isna().sum().rename("n_missing").to_csv(out / "missing_features.csv", index_label="feature")
    wiki = list(WIKIPEDIA_FEATURES)
    style = [n for n in names if n not in LENGTH_SENSITIVE_FEATURES and n not in wiki]
    feature_sets = {"style": style, "wikipedia": wiki, "combined": style + wiki,
                    "word_count_only": ["n_words"],
                    "length_only": ["n_words", "n_characters", "n_sentences"]}
    print("Computing paired effects and robustness after length matching...", flush=True)
    effects = effect_tables(df, names, seed=args.seed, n_bootstrap=args.bootstrap)
    effects.to_csv(out / "feature_effects.csv", index=False)
    shortlist, robustness = shortlist_features(df, effects, style + wiki)
    robustness.to_csv(out / "feature_robustness.csv", index=False)
    (out / "shortlist.json").write_text(json.dumps({"status": "exploratory_full_matched_sample_selection_requires_independent_validation", "features": shortlist,
                                                    "rule": {"min_abs_g_each_domain": .3, "min_generator_sign_fraction": 5/7, "max_spearman": .85, "maximum_size": 12}}, indent=2))
    print("Evaluating grouped logistic models, including pure word-count control...", flush=True)
    metrics, predictions = evaluate(df, feature_sets, seed=args.seed, n_splits=args.folds, n_bootstrap=args.bootstrap)
    metrics.to_csv(out / "classifier_metrics.csv", index=False)
    predictions.to_csv(out / "predictions.csv", index=False)
    controls = metrics[metrics.feature_set == "word_count_only"]
    if not controls.roc_auc.sub(.5).abs().lt(1e-12).all():
        raise RuntimeError("Pure word-count control is not exactly at chance; inspect paired folds and OOF predictions.")
    write_report(df, effects, metrics, shortlist, robustness, manifest, out)
    report_path = out / "report.md"
    report = report_path.read_text()
    report = report.replace("# Esperimento esplorativo: componente stilometrica", "# Esperimento stilometrico con controllo esatto della lunghezza")
    report = report.replace("Non si usano troncamenti a un numero fisso di parole; il manifest documenta l’eventuale rimozione simmetrica delle code senza terminazione di frase plausibile.",
                            f"Si conservano prefissi iniziali terminati con punteggiatura di frase, tra {args.minimum} e {args.maximum} parole lessicali, "
                            f"scegliendo conteggi ESATTAMENTE uguali nella coppia originale e vicini a {args.target}. Non si taglia a metà parola o frase. "
                            "Questo controllo riguarda brevi passaggi iniziali, non l’intero documento.")
    report += "\n## Controllo della lunghezza: cosa è stato pareggiato\n\n"
    report += "Ogni umano resta associato al generatore della stessa riga originale: gli abbinamenti non introducono dipendenze tra sorgenti diverse. "
    report += "La selezione con costo minimo rispetta quote 43/42 per generatore. Il conteggio di parole alfabetiche spaCy è esattamente uguale entro coppia: "
    report += "SMD=0 e KS=0 in tutti i domini e generatori. Si conservano gruppi di origine/prompt disgiunti nelle valutazioni.\n\n"
    report += markdown_table(balance[(balance.scope == "domain") & (balance.measure == "n_words")]) + "\n\n"
    report += "`word_count_only` misura soltanto il numero di parole: ROC-AUC=0.5 in tutti i protocolli. "
    report += "Il vecchio controllo `length_only` contiene anche caratteri e frasi: a parità di parole, questi esprimono lunghezza media delle parole e delle frasi, cioè componenti stilistiche volutamente non pareggiate.\n\n"
    report += "La scelta di prefissi con endpoint corrispondenti condiziona la selezione; lunghezza controllata non significa assenza di ogni confondente né prova causale di stile umano.\n"
    old_metrics_path = ROOT / "results/classifier_metrics.csv"
    if old_metrics_path.exists():
        old = pd.read_csv(old_metrics_path)
        keys = ["protocol", "domain", "generator", "feature_set"]
        comparison = old[keys + ["roc_auc", "macro_f1"]].merge(metrics[keys + ["roc_auc", "macro_f1"]], on=keys, suffixes=("_original", "_length_matched"))
        comparison["auc_change"] = comparison.roc_auc_length_matched - comparison.roc_auc_original
        comparison.to_csv(out / "comparison_with_original.csv", index=False)
        report += "\n## Confronto con l’esperimento precedente\n\n"
        report += markdown_table(comparison[(comparison.protocol == "leave_domain_out") & comparison.feature_set.isin(["style", "wikipedia", "combined"])]) + "\n\n"
        report += "I due esperimenti usano campioni e passaggi differenti: la differenza di AUC è descrittiva, non una stima causale dell’effetto della sola lunghezza.\n"
    report_path.write_text(report)
    old_shortlist = ROOT / "results/shortlist.json"
    previous = json.loads(old_shortlist.read_text()).get("features", []) if old_shortlist.exists() else []
    pd.DataFrame([{"feature": f, "original_selected": f in previous, "matched_selected": f in shortlist}
                  for f in sorted(set(previous).union(shortlist))]).to_csv(out / "shortlist_before_after.csv", index=False)
    (out / "run_metadata.json").write_text(json.dumps({"utc_started": utc, "seed": args.seed, "pairs_per_domain": args.pairs,
        "prefix_range": [args.minimum, args.maximum], "prefix_target": args.target, "exact_word_match": True,
        "bootstrap_replicates": args.bootstrap, "folds": args.folds, "feature_sets": feature_sets, "versions": versions,
        "sample_sha256": manifest["samples_sha256"], "elapsed_seconds": round(time.monotonic()-started, 2),
        "code_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in [ROOT / "stylometry/length_matching.py", ROOT / "stylometry/features.py", ROOT / "stylometry/analysis.py", Path(__file__)]},
        "shortlist_is_exploratory": True}, indent=2))
    print(metrics[["protocol", "domain", "generator", "feature_set", "roc_auc", "macro_f1"]].to_string(index=False), flush=True)
    print("Matched exploratory shortlist:", shortlist, flush=True)
    print("Results:", out, flush=True)


if __name__ == "__main__":
    main()
