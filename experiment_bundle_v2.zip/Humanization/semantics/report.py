"""Report executed semantic metrics and distinguish unavailable stages."""
from __future__ import annotations
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from stylometry.report import markdown_table


def _interval(values, rng, n_bootstrap=1000):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 2:
        return np.nan, np.nan
    draws = rng.choice(values, (n_bootstrap, len(values)), replace=True).mean(axis=1)
    return tuple(np.quantile(draws, [.025, .975]))


def write_semantic_report(pairs, output, seed=42):
    output = Path(output)
    manifest = json.loads((output / 'preparation_manifest.json').read_text())
    metadata = []
    for pair in pairs:
        item = {key: pair.get(key) for key in ['id', 'source_id', 'domain', 'generator', 'perturbation', 'dataset']}
        item['comparison'] = pair.get('metadata', {}).get('comparison', 'controlled')
        item['control_for'] = pair.get('metadata', {}).get('control_for')
        metadata.append(item)
    frame = pd.DataFrame(metadata)
    stages = []
    expected_hash = manifest['pairs_sha256']
    for name in ['lexical', 'embedding', 'bertscore', 'nli']:
        path = output / (name + '.csv')
        run_path = output / (name + '_run.json')
        if not path.is_file():
            continue
        run = json.loads(run_path.read_text())
        if run['pairs_sha256'] != expected_hash:
            raise ValueError(f'Stale {name} scores from different input pairs; rerun this stage')
        scores = pd.read_csv(path).drop(columns=['pair_id'], errors='ignore')
        if scores.id.duplicated().any() or set(scores.id) != set(frame.id):
            raise ValueError(f'{name}: scores do not cover exactly the prepared pairs')
        frame = frame.merge(scores, on='id', validate='one_to_one')
        stages.append(run)
    frame.to_csv(output / 'scores.csv', index=False)
    metric_columns = [c for c in frame.select_dtypes(include='number') if
                      c.startswith(('lexical_', 'embedding_cosine', 'local_', 'bert_chunk_', 'nli_forward_', 'nli_reverse_'))
                      and not c.endswith(('_chunks', '_tokens', '_threshold'))]
    rng = np.random.default_rng(seed)
    rows = []
    for key, part in frame.groupby(['dataset', 'perturbation', 'comparison'], sort=True):
        for metric in metric_columns:
            valid = part.dropna(subset=[metric])
            if not len(valid):
                continue
            # Sources, not multiple editors/variants of the same source, are
            # the independent bootstrap units and receive equal weight.
            values = valid.groupby('source_id')[metric].mean()
            low, high = _interval(values.to_numpy(), rng)
            rows.append(dict(zip(['dataset', 'perturbation', 'comparison'], key), metric=metric,
                             n_pairs=len(valid), n_sources=len(values), mean=values.mean(), median=values.median(),
                             ci_low=low, ci_high=high))
    summary = pd.DataFrame(rows)
    summary.to_csv(output / 'metric_summary.csv', index=False)
    deltas = []
    for prefix in ['nli_', 'local_nli_']:
        a, b = prefix + 'forward_mean', prefix + 'reverse_mean'
        if a in frame and b in frame:
            for key, part in frame.groupby(['dataset', 'perturbation', 'comparison'], sort=True):
                values = (part[a] - part[b]).groupby(part.source_id).mean().dropna()
                if len(values):
                    low, high = _interval(values.to_numpy(), rng)
                    deltas.append(dict(zip(['dataset', 'perturbation', 'comparison'], key),
                                       metric=prefix + 'forward_minus_reverse', n_sources=len(values),
                                       mean=values.mean(), ci_low=low, ci_high=high))
    pd.DataFrame(deltas).to_csv(output / 'directional_deltas.csv', index=False)
    paired_deltas = []
    identity = frame[(frame.dataset == 'controlled') & (frame.perturbation == 'identity')].set_index('source_id')
    local_identity = frame[frame.dataset == 'local_control'].set_index('control_for')
    for condition, part in frame[(frame.dataset == 'controlled') & (frame.perturbation != 'identity')].groupby('perturbation'):
        for metric in metric_columns:
            if metric.startswith('local_'):
                baseline = part.id.map(local_identity[metric]) if metric in local_identity else None
            else:
                baseline = part.source_id.map(identity[metric]) if metric in identity else None
            if baseline is None:
                continue
            values = (part[metric] - baseline).groupby(part.source_id).mean().dropna()
            if len(values):
                low, high = _interval(values.to_numpy(), rng)
                paired_deltas.append({'perturbation': condition, 'metric': metric,
                                      'n_sources': len(values), 'mean_delta_from_same_source_identity': values.mean(),
                                      'ci_low': low, 'ci_high': high})
    pd.DataFrame(paired_deltas).to_csv(output / 'paired_identity_deltas.csv', index=False)
    control = frame[frame.dataset == 'controlled']
    if 'lexical_rouge_l_f1' in control:
        names = ['identity', 'negation', 'entity_substitution', 'sentence_shuffle', 'truncate', 'random_deletion']
        fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
        for ax, column, title in zip(axes, ['lexical_rouge_l_f1', 'lexical_bleu'], ['ROUGE-L F1', 'BLEU (0–1)']):
            groups = [control.loc[control.perturbation == name, column].dropna().to_numpy() for name in names]
            ax.boxplot(groups, tick_labels=names, showfliers=False)
            ax.tick_params(axis='x', rotation=35, labelsize=8)
            ax.set_ylim(0, 1.03)
            ax.set_title(title)
        fig.suptitle('200 testi macchina: perturbazioni controllate, documenti interi')
        fig.tight_layout()
        fig.savefig(output / 'lexical_perturbations.png', dpi=170)
        fig.savefig(output / 'lexical_perturbations.pdf')
        plt.close(fig)
    pending = json.loads((output / 'pending_stages.json').read_text()) if (output / 'pending_stages.json').is_file() else []
    applied = pd.DataFrame([{'perturbazione': k, 'applicate': v, 'saltate': manifest['skipped_counts'].get(k, 0)}
                            for k, v in manifest['applied_counts'].items()])
    selected_summary = summary[(summary.dataset == 'controlled') & summary.metric.isin(
        ['lexical_rouge_l_f1', 'lexical_bleu', 'embedding_cosine', 'bert_chunk_f1', 'nli_forward_mean', 'nli_reverse_mean'])]
    lines = ['# Esperimento semantico: risultati eseguiti e stadi pendenti', '',
             f"Testi macchina originali: **{manifest['n_source_machine_documents']}**; seed {seed}. "
             'Campione selezionato tra i testi idonei a tutte le trasformazioni, bilanciando dominio e generatore per quanto consentito dagli idonei. '
             'Questa selezione introduce un bias esplicito: le frasi ambigue o senza entità non vengono rappresentate. '
             'Le trasformazioni non applicabili sono contate, non sostituite con identità; vedere `eligibility_manifest.json`.', '',
             markdown_table(applied), '',
             '## Metriche effettivamente eseguite', '',
             markdown_table(pd.DataFrame(stages)[['stage', 'n_pairs', 'elapsed_seconds', 'peak_rss_mib']]) if stages else 'Nessuna metrica eseguita.', '',
             markdown_table(selected_summary[['perturbation', 'metric', 'n_pairs', 'mean', 'ci_low', 'ci_high']]), '',
             'Gli IC 95% ricampionano i documenti sorgente (1.000 bootstrap), assegnando uguale peso a ciascuna fonte. '
             'Non descrivono l’incertezza della correttezza semantica delle perturbazioni. '
             '`paired_identity_deltas.csv` confronta ogni trasformazione con l’identità della stessa sorgente; '
             'i confronti locali usano l’esatta frase target contro se stessa.', '',
             '![Metriche lessicali](lexical_perturbations.png)', '',
             '## Stadi non eseguiti', '',
             markdown_table(pd.DataFrame(pending)) if pending else 'Nessuno stadio neurale pendente dichiarato.', '',
             '**OpAI-Bench:** ' + json.dumps(manifest['opai'], ensure_ascii=False), '',
             'Le celle neurali mancanti non sono stime e non sono state riempite con valori attesi. '
             'Finché embedding, BERTScore e NLI non vengono eseguiti, l’ipotesi «coseno/BERTScore alti, NLI basso con negazione» resta non verificata.', '',
             '## Definizioni e interpretazione', '',
             '- ROUGE-L F1 usa stemming Porter; BLEU è SacreBLEU 13a, smoothing esponenziale, effective_order=True, una reference, scala0–1. Le versioni locali sono sulle frasi effettivamente modificate.',
             '- Coseno: medie normalizzate e pesate per token delle rappresentazioni di frasi/chunk MiniLM, senza troncamento del documento.',
             '- BERTScore locale: RoBERTa-base layer10, IDF=False, rescale_with_baseline=False. Per documenti lunghi si usa una distinta approssimazione con matching di chunk, non il BERTScore integrale troncato.',
             '- NLI: DeBERTa-v3-base addestrato su MNLI/FEVER/ANLI. Forward significa originale→modificato; reverse modificato→originale. La mappa delle etichette viene letta dal config. Le probabilità non sono una prova logica.',
             '- Per ogni frase/chunk ipotesi si recuperano fino a3 candidati e si conserva il supporto massimo. Si riportano media, minimo, q10, quota sotto0.5 e contraddizione; il massimo può sovrastimare il supporto e il retrieval può perdere evidenza distribuita. I target locali evitano retrieval e diluizione.',
             '- Negazione: alterazione intenzionale, non gold contradiction verificata per tutti i casi. Entity swap: contenuto alterato o non supportato, non necessariamente contraddittorio. Troncamento e omissione: spesso neutralità nella direzione che richiede informazione persa.',
             '- Shuffle conserva le proposizioni: un NLI aggregato per frase può legittimamente restare alto. Questo test segnala il limite rispetto a coerenza e ordine narrativo.',
             '- Le versioni OpAI sono cumulative: confronti principali v3→v4 Compress e v4→v5 Expand; v0→v4/v5 sono secondari. Le espansioni senza nuove informazioni possono essere entailed in entrambe le direzioni.', '',
             '## Ripresa', '',
             'Scaricare modelli e dati con i comandi del README dopo aver autorizzato i domini nella configurazione. '
             'Eseguire gli stadi mancanti e poi `--stage report`, senza rigenerare il campione. '
             'Ogni stadio gira in un processo separato; peak RSS viene registrato. Il limite4GiB non è dichiarato verificato per modelli mai eseguiti.', '',
             'File completi: `scores.csv`, `metric_summary.csv`, `directional_deltas.csv`, `preparation_manifest.json`, `*_run.json`. '
             'I testi delle coppie e i metadati esatti delle modifiche restano nei file locali ignorati `data/semantic/`.', '']
    (output / 'report.md').write_text('\n'.join(lines), encoding='utf-8')
