#!/usr/bin/env python3
"""Populate the unchanged NLI probability cache with validated float32 ORT.

Sort globally by token length to avoid padding work. This changes scheduling,
not evidence retrieval, labels, model weights, or aggregation.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import time
import numpy as np
import onnxruntime as ort
from transformers import AutoTokenizer


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model', type=Path, default=Path('data/models/nli'))
    p.add_argument('--onnx', type=Path, default=Path('data/models/nli_onnx/model.onnx'))
    p.add_argument('--data-dir', type=Path, default=Path('data/semantic_full'))
    p.add_argument('--output', type=Path, default=Path('results_semantic_full'))
    p.add_argument('--threads', type=int, default=4)
    p.add_argument('--batch-size', type=int, default=8)
    args = p.parse_args()
    start = time.monotonic()
    jobs = [json.loads(x) for x in (args.data_dir/'nli_jobs.jsonl').read_text().splitlines()]
    cache_path = args.data_dir/'nli_probability_cache.jsonl'
    lines = cache_path.read_text().splitlines()
    header = json.loads(lines[0])
    if header['model_path'] != str(args.model.resolve()):
        raise ValueError('Probability cache checkpoint does not match requested model')
    if header['config_sha256'] != hashlib.sha256((args.model/'config.json').read_bytes()).hexdigest():
        raise ValueError('Probability cache checkpoint config changed')
    cached = {row['key']: row['probabilities'] for row in map(json.loads, lines[1:])}
    initial_cached = len(cached)
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    options = ort.SessionOptions()
    options.intra_op_num_threads = args.threads
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    session = ort.InferenceSession(str(args.onnx), sess_options=options, providers=['CPUExecutionProvider'])
    input_names = {x.name for x in session.get_inputs()}
    def predict(batch):
        encoded = tokenizer([x['premise'] for x in batch], [x['hypothesis'] for x in batch],
                            padding=True, truncation=False, return_tensors='np')
        if encoded['input_ids'].shape[1] > 384:
            raise ValueError('Planned evidence exceeds the NLI token budget; refusing truncation')
        logits = session.run(None, {k:v for k,v in encoded.items() if k in input_names})[0]
        exp = np.exp(logits-logits.max(axis=-1, keepdims=True))
        return exp/exp.sum(axis=-1, keepdims=True)
    # Validate the optimized backend against actual cached PyTorch outputs,
    # including ambiguous examples and a seeded random subset.
    references = [x for x in jobs if x['key'] in cached]
    rng = np.random.default_rng(42)
    margin = lambda x: sorted(cached[x['key']])[-1] - sorted(cached[x['key']])[-2]
    selected = sorted(references, key=margin)[:32]
    selected += [references[i] for i in rng.choice(len(references), min(96,len(references)), replace=False)]
    selected = list({x['key']:x for x in selected}.values())
    differences, classes, threshold = [], [], []
    config = json.loads((args.model/'config.json').read_text())
    entailment_index = next(int(i) for i,n in config['id2label'].items() if n.lower()=='entailment')
    for i in range(0,len(selected),args.batch_size):
        batch = selected[i:i+args.batch_size]
        actual = predict(batch)
        expected = np.array([cached[x['key']] for x in batch])
        differences.extend(np.abs(actual-expected).max(axis=1).tolist())
        classes.extend((actual.argmax(-1)==expected.argmax(-1)).tolist())
        threshold.extend(((actual[:,entailment_index]>=.5)==(expected[:,entailment_index]>=.5)).tolist())
    validation = {'n_real_cached_pairs':len(selected), 'max_probability_abs_difference':max(differences),
                  'mean_probability_max_abs_difference':float(np.mean(differences)),
                  'argmax_agreement':float(np.mean(classes)), 'entailment_threshold_0_5_agreement':float(np.mean(threshold)),
                  'tolerance':1e-4, 'precision':'float32', 'quantized':False}
    (args.output/'nli_onnx_real_pair_parity.json').write_text(json.dumps(validation,indent=2)+'\n')
    if max(differences)>1e-4 or not all(classes) or not all(threshold):
        raise ValueError('Float32 ONNX backend did not pass prespecified parity checks')
    pending = [x for x in jobs if x['key'] not in cached]
    for job in pending:
        job['tokens'] = len(tokenizer.encode(job['premise'],add_special_tokens=False))+len(tokenizer.encode(job['hypothesis'],add_special_tokens=False))
    pending.sort(key=lambda x:x['tokens'])
    processed = 0
    for i in range(0,len(pending),args.batch_size):
        batch = pending[i:i+args.batch_size]
        probabilities = predict(batch)
        with cache_path.open('a') as handle:
            for job,prob in zip(batch, probabilities):
                handle.write(json.dumps({'key':job['key'],'probabilities':[float(x) for x in prob]},separators=(',',':'))+'\n')
        processed += len(batch)
        if processed%200 < args.batch_size or processed==len(pending):
            progress={'phase':'unique_evidence_pairs','completed':initial_cached+processed,'total':len(jobs),
                      'elapsed_seconds':time.monotonic()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                      'max_pair_tokens_this_batch':batch[-1]['tokens']+tokenizer.num_special_tokens_to_add(pair=True)}
            (args.output/'nli_precompute_progress.json').write_text(json.dumps(progress,indent=2)+'\n')
    result={'status':'executed','backend':'onnxruntime_cpu_float32','unique_model_pairs':len(jobs),
            'initial_cached_pytorch_pairs':initial_cached,'new_onnx_pairs':processed,
            'elapsed_seconds':time.monotonic()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
            'threads':args.threads,'batch_size':args.batch_size,'batching':'global_token_length_sorted',
            'onnx_sha256':hashlib.sha256(args.onnx.read_bytes()).hexdigest(),'parity':validation}
    (args.output/'nli_precompute_run.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    main()
