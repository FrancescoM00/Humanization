# Valutazione dei testi

Compilare semantic_audit_24.csv e naturalness_review_form.csv. I form non contengono nomi dei sistemi né score. Conservare le annotazioni separatamente dai risultati automatici; per più valutatori usare copie distinte. Importare come CSV UTF-8, separatore virgola; testo a capo per i passaggi.

## Criteri semantici

Annotare `input_type_prose_instructions_mixed` come `prose`, `instructions` o `mixed`. La distinzione serve a identificare un eventuale cambio di compito, come rispondere a una consegna anziché riscriverla.

In `semantic_preserved_yes_partial_no`:

- `yes`: conserva le informazioni rilevanti e la forza delle affermazioni; variazioni di forma, fusione o divisione delle frasi sono ammesse.
- `partial`: conserva il quadro principale ma cambia o omette qualche informazione rilevante, oppure aggiunge contenuti non supportati dal passaggio.
- `no`: sostituisce il compito o altera ampiamente il contenuto.

In `error_type` indicare uno o più tipi: `omission`, `unsupported_addition`, `number_value`, `number_bound`, `entity`, `negation`, `hedging_or_claim_strength`, `task_shift`. Nelle note citare brevemente il punto preciso. Un'aggiunta non supportata dall'input non è automaticamente falsa nel mondo; qui si valuta la fedeltà al passaggio, non un fact-check esterno.

Non usare NLI, detector o giudizi della review dell'assistente come gold. È possibile annotare incertezza nelle note; non forzare una decisione sicura quando l'originale è ambiguo.

## Criteri di naturalezza

Valutare il testo singolo con `naturalness_1_to_5`: 1 molto artificiale/innaturale, 3 intermedio, 5 molto naturale nel suo genere. Considerare registro, formulazioni, ritmo e coerenza linguistica; annotare separatamente i motivi. Il voto non misura l'origine effettiva né la correttezza fattuale, e non va copiato da Flesch o dalla distanza stilometrica.

Un valutatore fornisce un primo controllo esplorativo; eventuali giudizi di più lettori vanno conservati separatamente. Le etichette ora presenti nei form sono tutte vuote.
