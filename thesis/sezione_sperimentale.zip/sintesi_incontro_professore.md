# Valutazione delle riscritture: sintesi per l’incontro

**Stato del lavoro: 10 novembre 2026 — annotazioni umane in raccolta.**

## Obiettivo e approccio

Valutare se una riscrittura riesce a ridurre la rilevazione automatica mantenendo significato e qualità della prosa. Si osservano separatamente **evasione, conservazione del significato, cambiamento di stile e naturalezza**: un risultato favorevole su un asse non garantisce gli altri. Il perimetro attuale è la **parafrasi mediante modelli linguistici con configurazioni fissate**, senza servizi commerciali.

Il lavoro segue due passaggi: prima verificare gli strumenti su confronti umano/macchina e modifiche controllate; poi applicarli alle riscritture reali. Il repository conserva codice, configurazioni, testi, score e report. Le inferenze principali sono già eseguite.

## Dati e strumenti utilizzati

Lo studio stilometrico comprende **1.800 testi, cioè 900 coppie umano/macchina**, nei domini Essay, Reuters e WritingPrompts di MGTBench. Il confronto è stato ripetuto pareggiando la lunghezza. OpAI-Bench e perturbazioni costruite a regole servono a verificare le metriche semantiche.

Lo studio sulle riscritture comprende **126 fonti**, sei per ciascuna combinazione di tre domini e sette generatori storici. Include i 42 pilot: le **84 fonti aggiuntive** sono riportate separatamente. Le soglie dei detector usano 300 gruppi umani di calibrazione, separati dal test. Quattro riscrittori e identità producono **630 esiti: 500 riscritture valide, quattro troncate e 126 identità**. I fallimenti restano registrati.

| Componente | Modelli o strumenti |
|---|---|
| Riscrittori | Qwen2.5-3B FP16; Qwen2.5-14B NF4, stesso prompt; DIPPER XXL NF4 sul passaggio intero e a finestre di tre frasi con contesto |
| Detector | OpenAI RoBERTa-base, Fakespot, RADAR; Binoculars con due Falcon 7B, base/instruct |
| Significato | ROUGE-L, BLEU; MiniLM `all-MiniLM-L6-v2`; BERTScore RoBERTa-base; DeBERTa-v3 **base float32** per l’entailment |
| Stile e naturalezza | spaCy piccolo, textstat, MATTR; giudice Groq `qwen/qwen3.8-27b`, senza ragionamento |

FP16 e NF4 indicano precisioni numeriche diverse: il confronto 3B/14B non isola la sola dimensione del modello. Per lo stile si estraggono 105 feature; la distanza RMS usa 91 feature standardizzate sugli umani. Tale distanza misura cambiamento, non naturalezza.

## Risultato centrale: l’evasione dipende dal detector

Sulle **84 fonti aggiuntive**, ASR indica evasioni fra gli originali già rilevati:

| Riscrittore | OpenAI | Binoculars | Fakespot |
|---|---:|---:|---:|
| Baseline 3B | 28/49 | 9/80 | 0/72 |
| 14B NF4 | 41/49 | 21/80 | 0/72 |

Fakespot passa da **70 a 82 rilevazioni su 82 output validi** per 3B e da **72 a 84 su 84** per 14B. Su RADAR l’aumento nelle fonti nuove è meno preciso. Binoculars ha invece evasioni reali; il suo falso positivo sugli umani test è **6/126 = 4,76%** (IC 95% circa 2,2–10,0%).

Il vantaggio del 14B non è riprodotto dal solo accorciamento: su Binoculars, nello stesso sottoinsieme eleggibile, **19/68 evasioni della riscrittura contro 0/68 dei prefissi**. Per DIPPER sul detector storico non emerge un vantaggio aggregato chiaro sul taglio. Gli intervalli disponibili sono esplorativi; non è ancora eseguita una revisione complessiva con correzione multipla.

\newpage

## Significato, stile e naturalezza: cosa possiamo concludere

**Significato.** Coseno e BERTScore possono restare elevati davanti a cambiamenti verificabili. L’NLI controlla se un testo sostiene le affermazioni dell’altro, nelle due direzioni; può però sbagliare su numeri, cautele e riorganizzazioni. I punteggi di metriche diverse non sono direttamente confrontabili come percentuali di fedeltà.

La calibrazione separata usa **139 positivi presunti, 297 alterazioni e 137 identità, su 46 fonti**; il test storico è escluso. La regola fissata seleziona **premesse fino a due frasi/chunk e minimo bidirezionale**: AUC **0,9735**, IC 95% **[0,9566; 0,9874]**, media identità **0,9710**. AUC misura separazione, non accuratezza del 97%. Tre unità danno 0,9712, molto vicino; il documento intero fallisce il requisito di copertura. La verifica umana resta necessaria.

**Stile.** DIPPER a tre frasi accorcia meno: rapporto parole medio **0,920**, contro **0,758** del passaggio intero. Cambia meno anche le feature. Recupera contenuto in alcuni casi, ma conserva errori: non è ancora dimostrata una maggiore fedeltà secondo annotazioni umane.

**Naturalezza.** Groq completa **364/744 risposte nuove**: tutti i confronti sono parziali per budget o quota. Fra 89 coppie discordanti invertendo l’ordine, **85 scelgono B in entrambi gli ordini**. Il giudice non sostiene attualmente una classifica affidabile.

## Attività in corso e decisioni da discutere

Le **84 coppie reference**, da 21 fonti e quattro riscrittori, sono state inviate ai colleghi; **etichette ancora in attesa**. Serviranno a verificare l’NLI già fissato. Le 99 coppie diagnostiche rimangono un approfondimento separato. Seguiranno valutazione del giudice e revisione statistica; non è necessario ripetere adesso gli humanizer.

Domande per il professore:

1. **Perimetro:** è sufficiente studiare questi parafrasatori, dichiarando esplicitamente l’assenza di servizi commerciali?
2. **Naturalezza:** privilegiare giudizi umani oppure tarare il giudice su preferenze umane esterne, con un piccolo controllo di altra famiglia?
3. **Fedeltà:** confermare “yes” contro “partial/no” come verifica principale, conservando anche le tre classi e la gravità degli errori?
4. **Statistica:** adottare variazione del TPR come endpoint principale, 16 confronti complessivi con Holm e una regola esplicita per i quattro fallimenti? La specifica nuova va dichiarata successiva ai risultati, senza retrodatazione.
5. **Dimensione:** completare l’analisi delle 126 fonti e delle annotazioni oppure riservare un piccolo campione realmente non esaminato? L’estensione a 420 non è automatica.
