# Parte sperimentale: valutazione delle riscritture

## Obiettivo e impostazione del lavoro

L'obiettivo sperimentale è capire che cosa accade quando un testo generato da un modello viene riscritto per apparire più umano. Il problema non si esaurisce nel riuscire a superare un detector. Una riscrittura potrebbe diventare meno riconoscibile e, nello stesso tempo, eliminare un'informazione, cambiare un numero o rendere più categorica un'affermazione. Occorre quindi osservare separatamente i diversi effetti della trasformazione.

Si indica con $X$ il testo di partenza e con $X'$ la sua riscrittura. La valutazione considera quattro domande.

| Dimensione | Domanda alla quale risponde |
|---|---|
| Evasione | Il detector riconosce ancora il testo come generato da una macchina? |
| Conservazione del significato | La riscrittura mantiene informazioni, negazioni e forza delle affermazioni? |
| Stile | Quali caratteristiche linguistiche cambiano e quanto cambiano? |
| Naturalezza | Il risultato è scorrevole e appropriato al genere del testo? |

: Le quattro dimensioni della valutazione.

Le quattro dimensioni non sono intercambiabili. Cambiare molte parole non implica perdere significato; una frase più naturale non è necessariamente più fedele; avvicinarsi alle caratteristiche medie dei testi umani non garantisce una prosa migliore. Per questo il lavoro non assegna subito un unico voto complessivo. Produce un insieme di misure che permettono di distinguere questi comportamenti.

L'approccio segue due passaggi. Prima vengono studiati gli strumenti di valutazione su confronti nei quali il tipo di cambiamento è controllato. Per lo stile si confrontano testi umani e generati, verificando che le differenze non dipendano soltanto dalla lunghezza. Per il significato si applicano modifiche esplicite, come inserire una negazione, e si osserva quali metriche riescano a segnalarle. In seguito, la stessa impostazione viene applicata a riscritture effettivamente prodotte dai sistemi.

Il perimetro riguarda testi inglesi e riscrittura per parafrasi con configurazioni dichiarate di modelli linguistici. Non comprende una valutazione generale dei servizi commerciali presentati come humanizer. Anche i risultati positivi devono essere riferiti ai dati, ai modelli e ai protocolli utilizzati.

## Dati e costruzione dei confronti

### Testi umani e generati da MGTBench

La prima analisi utilizza tre domini di MGTBench: Essay, che comprende testi di tipo saggistico; WritingPrompts, dedicato alla scrittura narrativa; Reuters, relativo a testi di notizie. La disponibilità di generi differenti permette di verificare se una caratteristica osservata in un ambito rimanga utile anche negli altri.

I tre file contengono, per ogni riga, un testo umano e le generazioni associate alla stessa origine. Sono disponibili sette generatori storici: ChatGPT, ChatGPT-turbo, ChatGLM, Claude, Dolly, GPT4All e StableLM. Si tratta di generazioni già presenti nel corpus, non di nuove richieste effettuate a quei modelli durante questo lavoro. Per ogni dominio vengono selezionati 300 testi umani e 300 testi macchina: in totale 900 coppie e 1.800 testi. Ogni umano è associato a un solo testo generato della stessa riga, mantenendo quote di circa 42--43 esempi per generatore e dominio.

I CSV sono stati inizialmente acquisiti da un mirror pubblico fissato a una versione precisa. Successivamente sono stati confrontati con quelli forniti dall'autore come scaricati dalla cartella Google Drive indicata da TH-Bench: i file sono identici byte per byte. La base analizzata è quindi quella MGTBench usata nel confronto umano/macchina; non coincide con tutti gli insiemi di attacco distribuiti da TH-Bench.

La pulizia uniforma gli spazi, elimina le code senza una conclusione di frase plausibile, rimuove duplicati ed esclude le generazioni identiche a un testo umano. È richiesta una lunghezza minima di 50 parole separate da spazi dopo il taglio. Questi controlli rendono il materiale più uniforme, ma non certificano che ogni generazione sia una risposta adeguata: alcuni testi possono ancora contenere consegne, rifiuti o formule da chatbot.

Una stessa origine può produrre più generazioni o più trasformazioni. Il codice conserva quindi un identificatore del gruppo di fonte. Tutti i testi collegati a quel gruppo rimangono insieme quando si separano i dati per apprendere una regola e quelli sui quali verificarla. In caso contrario, il sistema potrebbe essere valutato su un testo molto vicino a uno già visto.

### Riscritture e controlli OpAI-Bench

Per studiare l'editing si utilizza anche OpAI-Bench, che contiene versioni successive di uno stesso testo.[^fond-opai] Le operazioni considerate sono Polish, Paraphrase, Style Rewrite, Compress ed Expand: rispettivamente rifinitura, parafrasi, cambiamento di stile, compressione ed espansione.

Le versioni sono cumulative. Il confronto principale riguarda perciò due versioni adiacenti, per esempio prima e dopo Compress, anziché confrontare sempre l'ultima versione con il testo iniziale. In questo modo si osserva l'ultima operazione senza attribuirle anche gli interventi precedenti.

In OpAI il testo iniziale è umano. Il dataset serve quindi a controllare il comportamento delle metriche sulle riscritture, ma non è già un esperimento completo macchina--humanizer. Inoltre, il nome dell'operazione non è una garanzia: un intervento richiesto come conservativo può comunque cambiare qualche dettaglio. Le coppie Polish, Paraphrase e Style vengono trattate come esempi di conservazione *presunta*, da distinguere dalle etichette umane raccolte direttamente.

Le analisi stilistiche impiegano 200 traiettorie comuni, cioè sequenze di versioni collegate. Il confronto semantico principale appaia invece ogni riscrittura conservativa a una sua versione ulteriormente alterata. Il riferimento cambia così il meno possibile: non si confrontano soltanto testi corretti di un corpus con testi alterati di un altro.

## Misurare lo stile e controllare la lunghezza

### Le caratteristiche estratte

Lo stile viene rappresentato attraverso 105 caratteristiche numeriche, dette *feature*, calcolate con la stessa procedura su tutti i testi. spaCy, con il modello inglese piccolo, individua token, frasi e categorie grammaticali. Un token è un’unità in cui il programma divide il testo, per esempio una parola o un segno di punteggiatura. Nei modelli neurali un token può essere anche una parte di parola: un limite di 512 token non coincide quindi con 512 parole. textstat fornisce indicatori di leggibilità. La diversità lessicale MATTR è implementata direttamente nel progetto.[^fond-tools]

| Famiglia | Esempi di misure |
|---|---|
| Struttura delle frasi | Lunghezza media e variabilità della lunghezza |
| Punteggiatura | Frequenza di virgole, punti, trattini e altri segni |
| Categorie grammaticali | Quote di nomi, verbi, aggettivi, congiunzioni e numerali |
| Parole funzionali | Frequenze di articoli, preposizioni, pronomi e forme frequenti |
| Lessico e leggibilità | Lunghezza delle parole, MATTR e indicatori textstat |
| Indicatori ispirati a Wikipedia | Lessico ricorrente, formule conclusive e alcune scelte di formattazione |

: Famiglie delle caratteristiche stilometriche estratte.

Le categorie grammaticali sono indicate anche con la sigla POS, da *part of speech*. Una misura POS descrive una quota di token, non il loro significato. Le frequenze sono normalizzate per rendere confrontabili testi di lunghezza diversa. I denominatori rimangono espliciti: le parole lessicali sono token alfabetici, mentre le distribuzioni POS includono anche categorie come i numerali ed escludono spazi e punteggiatura.

MATTR misura la varietà delle parole dentro finestre della stessa dimensione. La finestra utilizzata comprende 50 parole. Per ogni finestra si divide il numero di parole diverse per 50 e poi si mediano i risultati ottenuti scorrendo il testo. Le forme sono confrontate in minuscolo, senza unire automaticamente le loro diverse flessioni. Confrontare finestre uguali riduce l'effetto che la lunghezza ha sul semplice rapporto fra parole diverse e parole totali. Se il passaggio ha meno di 50 parole, MATTR rimane non definita: non viene sostituita con zero.

Gli indicatori ricavati dalla guida Wikipedia sono traduzioni di alcuni segnali in regole osservabili. Non rappresentano l'intera guida: il codice non può dedurre, da poche frequenze, se un'analisi sia superficiale o una citazione sia corretta.

### Perché pareggiare il numero di parole

La lunghezza è una possibile spiegazione alternativa delle differenze umano/macchina. Un testo lungo ha più occasioni di introdurre parole diverse e più frasi sulle quali misurare la variabilità. Un classificatore potrebbe quindi riconoscere la classe attraverso la quantità di testo, anziché attraverso lo stile.

Per controllare questo fattore vengono cercati prefissi che terminano a fine frase, contengono fra 90 e 180 parole lessicali e hanno un conteggio esattamente uguale entro ogni coppia. La selezione privilegia una lunghezza vicina a 150 parole e mantiene numerosità e quote dei generatori. Dopo l'estrazione delle feature si ricontrolla che i conteggi siano effettivamente uguali.

Il confronto riguarda dunque i passaggi iniziali, non tutto il documento. Anche la scelta dei prefissi può cambiare parte delle fonti disponibili: il confronto con il campione completo non viene interpretato come una misura causale del solo effetto della lunghezza. Il controllo elimina la differenza nel numero di parole; non impone invece che i due testi abbiano lo stesso numero di frasi o parole della stessa lunghezza.

### Differenze singole e segnale complessivo

Per ogni feature si confrontano le medie delle due classi rispetto alla loro variabilità. Se due medie differiscono poco rispetto alle differenze fra testi della stessa classe, quella feature separa debolmente umano e macchina. Se la distanza è grande rispetto alla variabilità, il segnale è più evidente.

Questa idea viene espressa con Hedges $g$: la differenza fra media macchina e media umana, divisa per una deviazione standard comune, con una piccola correzione per la numerosità.[^fond-stat] Il segno indica la direzione; il valore assoluto indica la dimensione della differenza. Gli intervalli sono ottenuti ricampionando le fonti, cioè ripetendo il calcolo su campioni estratti con reinserimento dai gruppi originari.

Poiché vengono esaminate molte feature, alcune differenze possono emergere per caso. La procedura Benjamini--Hochberg corregge i confronti multipli controllando la quota attesa di false scoperte fra quelle segnalate. Questo controllo non rende una feature universale: la stabilità viene verificata anche separando domini e generatori.

Per misurare il segnale complessivo viene inoltre usata una regressione logistica. È un classificatore semplice che combina le feature attraverso pesi appresi dai dati. Sostituzione dei valori mancanti e standardizzazione sono apprese soltanto sul training, cioè sulla parte usata per costruire il modello. La valutazione usa fonti separate e parametri mantenuti fissi. Questo è il modello appreso sui dati dell'esperimento; i modelli neurali usati come strumenti di misura sono invece preaddestrati e non vengono riaddestrati sui nostri testi. Il modello stilometrico non coincide con i detector impiegati successivamente per misurare l'evasione.

La prestazione è descritta soprattutto dall'AUC. Questo indicatore misura quanto bene un punteggio ordina le due classi: circa 0,5 indica una separazione vicina al caso, mentre 1 indica separazione completa nel campione considerato. Non è la percentuale di testi classificati correttamente a una determinata soglia.

## Risultati dell'analisi stilometrica

Dopo il pareggiamento delle parole, un modello che usa soltanto il loro numero ha AUC 0,500. Le feature di stile conservano invece un segnale utile nello stesso dominio. Il trasferimento è però più debole quando il dominio sul quale si valuta non compare nell'addestramento.

| Dominio di valutazione | AUC nello stesso dominio | AUC addestrando sugli altri domini | AUC dei soli indicatori Wikipedia nello stesso dominio |
|---|---:|---:|---:|
| Essay | 0,876 | 0,670 | 0,569 |
| Reuters | 0,928 | 0,759 | 0,549 |
| WritingPrompts | 0,881 | 0,580 | 0,510 |

: Separazione umano/macchina dopo il pareggiamento della lunghezza.

La differenza fra le prime due colonne mostra che una parte del segnale dipende dal genere. La verifica lasciando fuori un generatore mostra inoltre che il comportamento non è uniforme fra modelli. Per esempio, l'AUC stilometrica è circa 0,933 quando si esclude GPT4All e 0,669 quando si esclude StableLM. Non basta quindi una buona separazione in un singolo insieme per sostenere il riconoscimento di qualunque generatore.

La lista breve esplorativa contiene quattro feature: quota di numerali (`pos_num`), quota di congiunzioni coordinanti (`pos_cconj`), MATTR a 50 parole (`mattr_50`) e quota di nomi propri (`pos_propn`). Come criterio operativo si richiede una dimensione dell’effetto almeno pari a 0,3 in valore assoluto, con direzione coerente nei tre domini e in almeno cinque generatori su sette. Si eliminano inoltre misure troppo correlate, per evitare di mantenere più copie dello stesso segnale. Il valore 0,3 è una regola esplorativa di selezione, non una soglia che garantisce il riconoscimento dell’autore. La lista è ricavata dall'intero campione e rimane una proposta da verificare, non una selezione indipendente già confermata sullo stesso test.

I proxy Wikipedia sono molto più deboli delle feature stilometriche nel loro insieme. La conclusione riguarda queste regole e questi dati, non l'impossibilità generale di riconoscere caratteristiche descritte dalla guida.

### Che cosa cambia durante l'editing

Le feature vengono poi calcolate sulle versioni OpAI. Una modifica può interessare poche frasi: la media dell'intero documento rischia di nasconderla. Si studiano quindi sia il documento sia le sole posizioni toccate, ricostruite dall'ordine nativo delle frasi e dalle etichette di editing.

Per descrivere il cambiamento con un solo numero si usa anche una distanza RMS: si standardizzano le variazioni delle feature e si calcola la radice della loro media quadratica. La standardizzazione serve perché una variazione in una frequenza grammaticale e una variazione in un conteggio non hanno la stessa scala. Per questa analisi le scale sono apprese dalle sole frasi iniziali delle fonti di calibrazione.

Nel test di 103 traiettorie, da 99 fonti, la distanza media per frase è 0,366 per Polish, 0,717 per Paraphrase e 0,656 per Style Rewrite. Non compare quindi l'intero ordine atteso Polish < Paraphrase < Style. Pesando anche quanto documento è stato toccato, i valori diventano 0,152, 0,369 e 0,425. Le due letture rispondono a domande diverse: quanto cambia una frase interessata e quanta parte del testo viene modificata. Non si sceglie la distanza soltanto perché restituisce l'ordine desiderato, né la si interpreta come naturalezza.

## Misurare la conservazione del significato

### Metriche che osservano aspetti diversi

L'esempio «The treatment is effective» e «The treatment is not effective» chiarisce il problema. Le due frasi condividono quasi tutte le parole, ma la negazione cambia l'affermazione. Una misura di somiglianza e una misura di supporto informativo possono quindi dare risposte diverse.

ROUGE-L e BLEU osservano soprattutto il riuso di parole e sequenze. ROUGE-L considera una sottosequenza comune rispettando l'ordine; BLEU misura la corrispondenza di sequenze brevi. Sono utili per descrivere quanto una formulazione sia rimasta vicina all'altra, ma una parafrasi corretta può usare parole differenti.

Il coseno usa invece vettori prodotti da all-MiniLM-L6-v2: rappresentazioni numeriche del contenuto.[^fond-models] Un valore vicino a uno indica rappresentazioni simili. BERTScore confronta rappresentazioni contestuali dei token, qui ottenute con RoBERTa-base, e cerca corrispondenze anche fra parole diverse. Queste misure possono cogliere vicinanza di argomento e formulazione senza accorgersi di ogni cambiamento fattuale.

L'NLI, da *natural language inference*, riceve una premessa e un'ipotesi. Con DeBERTa-v3 base il sistema assegna punteggi a supporto, contraddizione e neutralità. La domanda operativa è se il contenuto della premessa sostenga l'ipotesi, non se quest'ultima sia vera nel mondo. Il testo di partenza può essere fattualmente sbagliato e la riscrittura conservarlo comunque; questa verifica non è fact-checking.

Si usano entrambe le direzioni: originale verso riscrittura e riscrittura verso originale. Se «Mario ha due cani e un gatto» diventa «Mario ha due cani», l'originale sostiene la versione corta, mentre da questa non si ricava più l'informazione sul gatto. Un calo nella direzione inversa è quindi compatibile con perdita di informazione. Le due direzioni aiutano a leggere il fenomeno, senza identificarne automaticamente la causa.

### Frasi, allineamento e aggregazione

I modelli hanno un limite di contesto. Per evitare di eliminare silenziosamente la fine dei testi, si lavora su frasi e, quando necessario, su segmenti più piccoli, chiamati chunk. I documenti sono rappresentati aggregando questi segmenti con le regole dichiarate. Il BERTScore documentale è quindi un'approssimazione basata sul confronto dei chunk, distinta dal calcolo standard su una frase breve.

Per ogni unità della riscrittura si cercano nell'originale le evidenze più pertinenti. Nel primo protocollo NLI i candidati sono recuperati tramite MiniLM, conservando il supporto massimo. I punteggi delle diverse unità possono essere riassunti con la media, il minimo, il decimo percentile oppure la quota senza supporto sufficiente.

La media descrive il comportamento complessivo; il minimo evidenzia l'unità meno supportata. Il decimo percentile, o q10, guarda la parte bassa della distribuzione senza coincidere sempre con il caso peggiore. In un testo con venti unità e una sola frase alterata, la media può diluire il difetto e q10 può riguardare una frase diversa. Il minimo può invece reagire a quell'unico errore, ma anche a un'unica frase difficile che è stata riscritta correttamente.

## Verifiche controllate delle metriche semantiche

### Errori espliciti e direzione dell'informazione

La baseline usa 200 testi macchina sui quali siano applicabili le trasformazioni previste. Si inserisce una negazione, si sostituisce un'entità, si mescolano le frasi, si tronca il testo oppure si cancellano parole casuali. Sono presenti anche identità: confronti nei quali il testo resta invariato. Servono a controllare che un eventuale calo non dipenda soltanto dal classificatore o dal modo in cui il documento viene segmentato.

Nella negazione, le medie documentali di coseno e BERTScore rimangono circa 0,998 e 0,999. L'NLI medio scende a circa 0,894: una sola frase pesa poco nella media del documento. Sulla frase modificata, invece, il supporto NLI scende a circa 0,001 e la contraddizione sale a circa 0,998. Anche il coseno locale diminuisce, fino a circa 0,869. Il risultato corretto è dunque che la media documentale può nascondere un errore locale, non che ogni misura di similarità sia completamente insensibile alla negazione.

Il troncamento mostra la direzione attesa: supporto originale--versione corta circa 0,992 e supporto inverso circa 0,669. In OpAI, Compress produce un'asimmetria più debole perché spesso elimina poco e conserva il contenuto essenziale. Expand può aggiungere informazioni che il precedente non sostiene. Al contrario, mescolare le frasi lascia quasi intatte molte proposizioni: l'NLI può restare alto pur non descrivendo bene l'ordine narrativo.

BERTScore viene riportato anche rispetto alla baseline ufficiale del modello. Un valore grezzo alto non ha la stessa interpretazione per tutti i confronti: una singola frase non correlata raggiungeva circa 0,865. Il riscalamento rispetto alla baseline 0,814463 rende la scala più leggibile, ma non cambia l'ordinamento né l'AUC.

### Parafrasi corrette presunte e confronto con gli stessi aggregatori

Le perturbazioni distruttive, da sole, non bastano. Una metrica potrebbe segnalare qualsiasi riscrittura, comprese quelle corrette. Vengono quindi aggiunte le riscritture conservative presunte OpAI e alterazioni più sottili: numeri, quantificatori, cautele rimosse e dettagli non presenti. Ogni negativo è ottenuto alterando un positivo collegato allo stesso originale.

Per rendere equo il confronto, anche coseno e BERTScore vengono calcolati sulle stesse unità locali, cercando la similarità massima nell'altro testo e usando media, q10 e minimo. Non si confronta soltanto un minimo NLI, sensibile al caso peggiore, con una media di similarità che lo diluisce.

Sul test appaiato di 141 positivi presunti e 265 alterazioni, da 48 fonti, le AUC del minimo sono 0,958 per NLI, 0,607 per coseno allineato e 0,534 per BERTScore allineato. L'NLI distingue meglio le due classi di questo pannello. Il risultato non è un'accuratezza del 95,8% sugli humanizer e non rende le etichette automatiche una verità umana.

Il minimo è favorito anche dal fatto che molti errori sono concentrati in una frase. Un ulteriore test, con 25 fonti per famiglia di corruzione, ripete gli interventi su una, due, tre e cinque frasi degli stessi documenti. Con più frasi alterate la media può raggiungere o superare il minimo. Inoltre, sui positivi il minimo tende a diminuire all'aumentare del numero di frasi: un documento più lungo offre più occasioni di trovare un supporto basso. Un controllo per fasce di lunghezza mantiene AUC NLI 0,951, ma non autorizza ad applicare a qualsiasi humanizer una soglia ricavata da OpAI.

Sono state aggiunte guardie lessicali che segnalano cambiamenti in negazioni, numeri, quantificatori e cautele. Sono avvisi interpretabili, non prove automatiche di errore: cambiare la forma di un numero può essere corretto e togliere una parola modale non sempre elimina la cautela dell'intera proposizione. Nel confronto svolto, la loro combinazione con NLI non migliora l'AUC complessiva. Le cautele restano uno dei casi da verificare attentamente.

### Revisione delle sostituzioni e controllo numerico

La lettura delle perturbazioni ha mostrato che il riconoscimento automatico delle entità può sbagliare persone, luoghi o confini dei nomi. È stata quindi introdotta una politica di sostituzione più prudente, separata dalla versione precedente. Essa applica 145 sostituzioni e ne salta 55 su 200 fonti, mantenendo i risultati originari.

Un ulteriore controllo considera soltanto 34 coppie: 18 date, sei importi e dieci percentuali. Il supporto NLI locale medio è 0,0026 sulle alterazioni e 0,9915 sulle identità corrispondenti, mentre coseno e BERTScore documentali rimangono circa 0,998 e 0,999. Il comportamento non dipende quindi soltanto dalle sostituzioni di nomi più problematiche. Tuttavia, confrontare un'alterazione con il testo identico è facile: anche le similarità separano queste due classi. Non è una dimostrazione di superiorità sulle parafrasi corrette o sugli errori numerici più sottili.

Le prove controllate indicano quindi quali strumenti siano informativi e dove possano fallire. Non sostituiscono l'esame delle riscritture reali. Il passaggio successivo applica questa suite a sistemi effettivamente eseguiti, mantenendo distinti evasione, fedeltà, stile e naturalezza.

[^fond-opai]: Dataset ufficiale OpAI-Bench: <https://huggingface.co/datasets/OpAI-Bench1/OpAI-Bench>; codice del benchmark: <https://github.com/VILA-Lab/OpAI-Bench>. Le revisioni e le selezioni effettive sono conservate nei manifest del progetto.
[^fond-tools]: spaCy: <https://spacy.io/models/en>; textstat: <https://pypi.org/project/textstat/>. Per MATTR: M. A. Covington e J. D. McFall, *Cutting the Gordian Knot: The Moving-Average Type--Token Ratio (MATTR)*, 2010, <https://doi.org/10.1080/09296171003643098>.
[^fond-stat]: L. V. Hedges, *Distribution Theory for Glass's Estimator of Effect Size and Related Estimators*, 1981, <https://doi.org/10.3102/10769986006002107>; Y. Benjamini e Y. Hochberg, *Controlling the False Discovery Rate: A Practical and Powerful Approach to Multiple Testing*, 1995, <https://doi.org/10.1111/j.2517-6161.1995.tb02031.x>.
[^fond-models]: Checkpoint impiegati: <https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2>, <https://huggingface.co/FacebookAI/roberta-base> e <https://huggingface.co/MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli>. BERTScore: T. Zhang et al., *BERTScore: Evaluating Text Generation with BERT*, <https://arxiv.org/abs/1904.09675>.


## Applicazione della suite a riscritture reali

Dopo le prove sui testi modificati in modo controllato, la suite è stata applicata a riscritture prodotte da modelli effettivi. Lo scopo è osservare insieme i quattro aspetti della valutazione: rilevabilità, conservazione del contenuto, cambiamento dello stile e naturalezza. Un risultato favorevole su un solo aspetto non basta a considerare riuscita la trasformazione. Per esempio, un testo può diventare meno riconoscibile da un detector perché è stato accorciato, ma perdere informazioni importanti.

Il passaggio ai modelli reali è avvenuto gradualmente. Una prima prova su tre fonti ha controllato che generazione e metriche fossero eseguibili. Sono seguiti due pilot sulle stesse 42 fonti, con la baseline Qwen da 3 miliardi di parametri e DIPPER. Infine è stato eseguito uno studio comune su 126 fonti con quattro configurazioni di riscrittura. Questa progressione ha permesso di risolvere i problemi tecnici prima di ampliare il campione, ma non produce tre campioni indipendenti: le tre fonti iniziali sono comprese nelle 42 e queste sono comprese nelle 126.

### Campione e separazione delle fonti

Le 126 fonti provengono da MGTBench e sono distribuite in modo uniforme: tre domini, sette generatori già presenti nel corpus e sei fonti per ciascuna combinazione. Ogni fonte identifica un testo macchina da riscrivere e il corrispondente testo umano del dataset. I generatori del corpus non sono i modelli usati per riscrivere: sono due ruoli distinti. Per esempio, un testo generato in origine da StableLM può essere successivamente riscritto da Qwen.

Si mantengono separati 300 gruppi di testi umani per fissare le soglie dei detector e le scale delle feature stilometriche. Questi testi non appartengono al campione di test. Inoltre, le 84 fonti aggiunte dopo i pilot vengono analizzate anche separatamente. In questo modo è possibile verificare se le tendenze osservate sui primi 42 casi si ritrovano su testi che non erano stati usati per formulare quelle osservazioni. Una nuova scelta decisa dopo aver letto tutte le 126 fonti, invece, non può essere presentata come precedente a quei risultati.

### Le quattro configurazioni di riscrittura

I sistemi ricevono lo stesso testo originale. Si effettua un solo tentativo per sistema e fonte, senza scegliere l'output più favorevole ai detector. La generazione è *greedy*: a ogni passo viene scelta la continuazione più probabile, senza campionamento casuale. Il prompt dei due Qwen chiede una prosa inglese più naturale, con variazione delle frasi, conservando fatti, nomi, numeri, negazioni e forza delle affermazioni.

| Nome usato nei risultati | Modello | Configurazione |
|---|---|---|
| Baseline 3B | Qwen2.5-3B-Instruct | Prompt fisso, precisione FP16 |
| 14B | Qwen2.5-14B-Instruct | Stesso prompt, quantizzazione NF4 |
| DIPPER passaggio | DIPPER XXL | Intero passaggio, nessun prefisso, NF4 |
| DIPPER tre frasi | DIPPER XXL | Finestre di tre frasi e contesto riscritto cumulativo, NF4 |

: Configurazioni di riscrittura applicate allo stesso campione.

Tutti questi modelli sono preaddestrati e usati senza ulteriore addestramento sui testi della tesi. Si modificano le istruzioni o la configurazione di generazione; non si aggiornano i loro pesi. Anche i detector e i modelli delle metriche rimangono fissi. La regressione logistica stilometrica, descritta in precedenza, è il modello addestrato nel progetto e non coincide con questo pool di detector.

FP16 rappresenta i pesi con precisione a 16 bit. NF4 è una rappresentazione a 4 bit che riduce la memoria necessaria. Il confronto 3B/14B cambia quindi sia il modello sia la precisione: un eventuale vantaggio non può essere attribuito alla sola dimensione.

DIPPER permette di controllare il cambiamento del lessico e dell'ordine. Nei due preset si usano diversità lessicale 60 e diversità d'ordine 0. Nel primo, il modello riceve il passaggio completo. Nel secondo, riscrive gruppi di tre frasi usando come contesto anche il testo già prodotto. Questa seconda soluzione si avvicina all'idea di una riscrittura progressiva, ma usa segmentazione spaCy e generazione greedy; non è una replica esatta di tutte le scelte del rilascio originale. Cambia anche il budget complessivo disponibile, perché viene assegnato a ciascuna finestra.

Si aggiunge un controllo di identità: il testo viene lasciato invariato e attraversa la stessa valutazione. Serve a controllare che le misure riconoscano l'assenza di una modifica. Le 126 identità non sono altrettante riscritture indipendenti.

## Misurare la rilevabilità prima e dopo la riscrittura

### Detector, soglie e testi lunghi

Il pool comprende tre classificatori supervisionati e un metodo zero-shot. I primi sono OpenAI RoBERTa-base, Fakespot e RADAR. Il primo è un detector storico addestrato su generazioni GPT-2. Fakespot e RADAR sono anch'essi classificatori della famiglia RoBERTa; il nome del checkpoint RADAR-Vicuna-7B non significa che qui venga caricato un modello causale Vicuna da 7 miliardi di parametri. Si conserva anche il voto di maggioranza dei tre classificatori, richiedendo due decisioni AI su tre. Questo voto riassume strumenti correlati e non costituisce una quarta prova indipendente.

Il metodo zero-shot è Binoculars. Confronta le previsioni di due modelli causali, Falcon-7B e Falcon-7B-Instruct, e produce un rapporto fra statistiche delle probabilità dei token. Non addestra un nuovo classificatore sul corpus della tesi. Un rapporto più basso indica maggiore compatibilità con testo macchina; non è una probabilità di origine AI. I due Falcon vengono caricati su due GPU T4 distinte con pesi FP16, mentre le statistiche sono calcolate in FP32.

Per confrontare le decisioni si fissano le soglie sui soli 300 umani di calibrazione, mirando a un tasso di falsi positivi del 5%. Non si sceglie la soglia osservando quali riscritture si vogliono far risultare efficaci. Binoculars usa una soglia sul proprio rapporto, con orientamento opposto a quello degli score AI dei classificatori. Le soglie rimangono le stesse durante il confronto fra sistemi.

I detector non ricevono soltanto un prefisso del documento. Per i classificatori il testo viene diviso in blocchi compatibili con il modello e gli score sono mediati pesando i token. Binoculars usa finestre con un token di sovrapposizione, così da valutare una volta ogni passaggio fra token. Si conservano quindi informazioni sull'intero testo, pur con il limite di contesto di ciascuna finestra.

### Come leggere FPR, TPR e ASR

Il *false positive rate* (FPR) è la quota di testi umani classificati erroneamente come macchina. Il *true positive rate* (TPR) è la quota di testi macchina riconosciuti. Il TPR prima e dopo la riscrittura mostra se il sistema di riscrittura riduce o aumenta la rilevabilità complessiva.

L'*attack success rate* (ASR) risponde a una domanda più specifica: fra gli originali che il detector riconosceva già, quanti non vengono più riconosciuti dopo la trasformazione? Il suo denominatore cambia quindi fra detector. Nel caso di OpenAI, il 14B ottiene 60 evasioni su 73 originali rilevati: l'ASR è 60/73, non 60/126. Questo evita di attribuire allo humanizer testi che il detector non riconosceva nemmeno prima.

Il confronto prima/dopo è appaiato: si considerano le stesse fonti. Gli intervalli sono ottenuti ricampionando i gruppi di fonte, mantenendo insieme i testi collegati. Nei risultati dei detector si usano 5.000 ricampionamenti. Gli intervalli mantengono fissi modelli e soglie: non includono l'intera incertezza dovuta alla calibrazione o all'addestramento. I confronti riportati sono esplorativi; una revisione formale degli endpoint principali e della correzione per confronti multipli resta da completare.

### Output non validi

I cinque sistemi, includendo l'identità, producono 630 esiti. Di questi, 626 sono validi. Quattro terminano al limite di generazione senza un output accettabile. La baseline 3B fallisce su due fonti StableLM contenenti consegne interne, alle quali risponde invece di riscriverle; entrambi i DIPPER entrano in ripetizioni sullo stesso racconto GPT4All. Nel preset contestuale il problema compare già nella prima finestra. Tutti questi casi appartengono alle 84 fonti nuove.

I fallimenti non sono rigenerati né rimossi per migliorare i risultati. Quando l'originale era rilevato, restano nel denominatore ASR come mancati successi. Semantica, stile e naturalezza richiedono invece una riscrittura disponibile: le rispettive medie usano gli output validi e riportano i conteggi. Anche il TPR dopo la riscrittura non può assegnare implicitamente una decisione a un testo inesistente. Si confrontano perciò le coppie valide, mantenendo separato il numero dei fallimenti.

Gli input contenenti istruzioni restano nel risultato principale secondo il criterio definito. Un'eventuale analisi sulla sola prosa richiederà di classificare gli originali: non è corretto escludere soltanto gli esempi per i quali l'output è sfavorevole.

## Risultati di evasione e controlli di lunghezza

### L'effetto dipende dal detector

La tabella riporta evasioni e relativi denominatori. I quattro detector riconoscono inizialmente 73, 109, 90 e 120 originali macchina su 126, rispettivamente.

| Configurazione | OpenAI | Fakespot | RADAR | Binoculars |
|---|---:|---:|---:|---:|
| Baseline 3B | 45/73 = 61,6% | 1/109 = 0,9% | 8/90 = 8,9% | 17/120 = 14,2% |
| 14B | 60/73 = 82,2% | 1/109 = 0,9% | 8/90 = 8,9% | 29/120 = 24,2% |
| DIPPER passaggio | 10/73 = 13,7% | 11/109 = 10,1% | 7/90 = 7,8% | 0/120 |
| DIPPER tre frasi | 6/73 = 8,2% | 8/109 = 7,3% | 11/90 = 12,2% | 1/120 = 0,8% |

: Evasioni sugli originali già rilevati, nell’intero campione di 126 fonti.

Il risultato principale è la diversa risposta dei detector alla stessa trasformazione. Il 14B evade spesso OpenAI e una parte di Binoculars, ma quasi mai Fakespot. L'82,2% su OpenAI non rappresenta quindi un successo generale: quel detector storico riconosceva soltanto 73 originali. Il voto dei tre RoBERTa dà ASR 4/94 per 3B, 6/94 per 14B, 7/94 per DIPPER passaggio e 6/94 per DIPPER tre frasi.

Il profilo si ritrova sulle 84 fonti aggiuntive. Il 14B evade OpenAI in 41/49 casi e Binoculars in 21/80, mentre la baseline 3B ottiene 28/49 e 9/80. La differenza appaiata 14B−3B su Binoculars è di 15 punti percentuali, con intervallo 95% da 6,3 a 23,8. Fakespot non viene evaso da nessuno dei due sistemi su quelle fonti.

Fakespot diventa anzi più efficace. Fra gli 82 output validi della baseline 3B sulle fonti nuove, riconosceva 70 originali e riconosce tutte le 82 riscritture. Per il 14B passa da 72 a 84 riconoscimenti su 84. Gli incrementi di TPR sono circa 14 punti percentuali, con intervalli che non comprendono zero. Su RADAR gli incrementi nelle sole 84 fonti sono meno precisi e i relativi intervalli comprendono zero. Non si conclude quindi che tutti i detector migliorino: la rilevabilità aumenta per Fakespot e diminuisce per Binoculars.

Il FPR di Binoculars sui 126 umani di test è 6/126, cioè 4,76%, compatibile con l'obiettivo del 5%. L'intervallo di Wilson al 95% è circa 2,2–10,0%: il dato non dimostra una calibrazione esatta nella popolazione. Gli altri FPR di test sono 4/126 per OpenAI, 4/126 per Fakespot e 3/126 per RADAR.

### Separare l'effetto della riscrittura da quello dell'accorciamento

Per ogni output sufficientemente corto si costruisce un controllo: il prefisso dell'originale con lo stesso numero di parole alfabetiche della riscrittura. Diversamente dal matching fra umani e macchine, qui il taglio può terminare dentro una frase, perché si vuole uguagliare esattamente la lunghezza. Se l'output è più lungo dell'originale, il controllo non è applicabile e non si aggiunge testo artificiale.

Un secondo controllo introduce al massimo una sostituzione lessicale da un dizionario fissato. Si valutano anche taglio e rumore combinati. Il rumore non è garantito semanticamente equivalente: serve a verificare quanto il detector reagisca a una modifica minima. I conteggi di eleggibilità sono riportati separatamente.

| Detector e sistema, 84 fonti nuove | Evasioni del prefisso | Evasioni della riscrittura |
|---|---:|---:|
| OpenAI, baseline 3B | 1/41 | 24/41 |
| OpenAI, 14B | 4/42 | 36/42 |
| Binoculars, baseline 3B | 0/62 | 5/62 |
| Binoculars, 14B | 0/68 | 19/68 |

: Controllo della lunghezza sulle fonti nuove: stessi casi per prefisso e riscrittura.

In questi confronti abbinati l'accorciamento da solo non riproduce il vantaggio delle riscritture a prompt. I denominatori sono più piccoli di quelli della tabella generale perché includono soltanto fonti eleggibili e già rilevate. Non si attribuisce tuttavia causalmente tutto il vantaggio allo stile: un prefisso elimina contenuto, mentre una riscrittura può cambiarlo in altri modi.

Per DIPPER su OpenAI non emerge un vantaggio aggregato chiaro rispetto al taglio. Sull'intero campione eleggibile, DIPPER passaggio e prefisso hanno entrambi 10/72 evasioni; DIPPER tre frasi e prefisso hanno entrambi 5/64. Le evasioni sono però spesso su esempi diversi. L'uguaglianza dei tassi non dimostra che il taglio abbia causato le medesime decisioni.

## Stile e significato delle riscritture

Le misure stilometriche usano le scale fissate sui 300 umani di calibrazione. La distanza RMS riassume la variazione di 91 feature utilizzabili fra le 105 estratte; indica quanto cambia la rappresentazione, non quanto migliora la scrittura. Le medie seguenti escludono i quattro output non validi.

| Configurazione | Output validi | Parole dopo/prima | Distanza RMS | Variazione MATTR |
|---|---:|---:|---:|---:|
| Baseline 3B | 124 | 0,962 | 0,831 | +0,0616 |
| 14B | 126 | 0,871 | 1,047 | +0,0813 |
| DIPPER passaggio | 125 | 0,758 | 0,796 | −0,0286 |
| DIPPER tre frasi | 125 | 0,920 | 0,651 | −0,0262 |

: Lunghezza e cambiamento stilometrico degli output validi.

Il 14B cambia maggiormente le feature, ma questo non equivale a maggiore naturalezza. DIPPER a tre frasi accorcia meno del passaggio: conserva in media il 92% delle parole, contro circa il 76%. Si avvicina anche più spesso al centroide umano, cioè al punto medio della rappresentazione dei testi umani. Nessuno dei due indicatori certifica la qualità. Le tendenze rimangono sulle 84 fonti nuove e sulle 123 fonti per cui tutti i sistemi producono un output valido.

Coseno documentale e BERTScore restano mediamente alti. I loro valori sono, rispettivamente, 0,937 e 0,946 per 3B, 0,903 e 0,927 per 14B, 0,925 e 0,948 per DIPPER passaggio, 0,951 e 0,964 per DIPPER tre frasi. Scale diverse non sono direttamente confrontabili come percentuali di significato conservato. Sono disponibili anche le versioni allineate per unità e i relativi minimi, così da non attribuire alla metrica ciò che dipende soltanto dalla media sul documento.

La lettura dei casi mostra sia recuperi sia errori. In Reuters 289, DIPPER passaggio cambia valuta e importi con coseno circa 0,939. In Reuters 889, il preset a tre frasi perde l'anno esplicito e rafforza una possibilità in affermazione, pur ottenendo entailment forward vicino a 0,99. Altri casi fondono informazioni di più frasi: una sola premessa può allora produrre un falso allarme. Sono letture dell'assistente, utili a individuare problemi ma non equivalenti alle annotazioni umane in raccolta.

## Scelta della configurazione NLI

I casi reali hanno reso evidente un problema: una frase riscritta può essere sostenuta da informazioni distribuite su due frasi dell'originale. Per questo sono state confrontate premesse singole, finestre fino a due o tre unità contigue e documento intero. Le unità sono frasi o chunk già fissati; l'ipotesi da verificare rimane la stessa. Per ciascuna ipotesi si sceglie il massimo entailment fra le premesse ammissibili.

Finestre più ampie offrono più occasioni di trovare supporto e possono quindi aumentare lo score anche per affermazioni alterate. Non basta osservare un aumento sui testi riscritti per scegliere il metodo. Dopo lo studio sulle 126 fonti è stata pertanto fissata una regola di selezione su un pannello diverso, usando soltanto lo split di calibrazione già disponibile: **139 positivi presunti, 297 alterazioni e 137 identità, su 46 fonti**. Le identità sono gli originali confrontati con se stessi. Le 141 coppie positive e 265 alterate dello storico test non vengono usate per questa scelta.

Si confrontano quattro modalità e quattro aggregatori: media, q10, minimo e quota di ipotesi con supporto sotto 0,5. Q10 è il decimo percentile: descrive la parte bassa degli score senza usare soltanto il caso peggiore. Il punteggio finale richiede entrambe le direzioni e prende il valore meno favorevole. Per essere ammissibile, un candidato deve coprire tutte le coppie e ottenere sulle identità una media almeno 0,95 e un decimo percentile almeno 0,90. Queste sono soglie operative di controllo, non regole universali di validità NLI. Fra i candidati ammissibili si massimizza l'AUC di calibrazione, con spareggi stabiliti prima del calcolo.

| Premesse, aggregatore minimo | AUC di calibrazione | Media degli score sulle identità |
|---|---:|---:|
| Singole esaustive | 0,9470 | 0,9668 |
| Fino a due unità | **0,9735** | **0,9710** |
| Fino a tre unità | 0,9712 | 0,9726 |
| Documento intero | Non calcolabile sul campione completo | Copertura insufficiente |

: Confronto delle premesse NLI sullo split di calibrazione, usando il minimo bidirezionale.

La regola seleziona **fino a due unità e minimo bidirezionale**, indicati nel codice come `window2 + min`. In pratica, ogni unità riscritta deve trovare supporto in una o due unità contigue; si conserva poi il supporto minimo, anche considerando la direzione inversa. Il confronto completa 323.336 evidenze con DeBERTa-v3 base FP32, in circa 54 minuti di inferenza GPU.

L'AUC selezionata ha intervallo bootstrap per fonte 95% [0,9566; 0,9874]. La differenza da tre unità è piccola e non dimostra superiorità fuori campione. Inoltre 0,9735 non significa 97,35% di testi valutati correttamente. È una misura di separazione sul campione di sviluppo e su etichette presunte; non va confrontata come miglioramento diretto con lo storico 0,958 ottenuto su un altro split.

Il documento è escluso perché completo in entrambe le direzioni solo per 77/436 coppie etichettate e 36/137 identità. Non gli si attribuisce una buona AUC eliminando i testi che non entrano nel budget. Anche il candidato scelto conserva limiti: tre identità hanno score sotto 0,90 e la famiglia delle cautele raggiunge AUC 0,891 su soli 15 casi. La buona separazione complessiva non dimostra uguale affidabilità per ogni errore.

Applicando lo score scelto alle riscritture già calcolate si ottiene il quadro seguente. Il controllo di identità serve come riferimento di coerenza, non come altro humanizer.

| Configurazione | Output valutabili | Score primario medio | Mediana |
|---|---:|---:|---:|
| Identità | 126 | 0,9828 | 0,9872 |
| Baseline 3B | 124 | 0,3461 | 0,1070 |
| 14B | 126 | 0,3489 | 0,1018 |
| DIPPER passaggio | 125 | 0,1315 | 0,0061 |
| DIPPER tre frasi | 125 | 0,3187 | 0,1022 |

: Score NLI primario sulle riscritture: minimo bidirezionale con premesse fino a due unità.

Questi valori descrivono il caso meno supportato del documento. Uno score basso può derivare da una sola unità problematica e non significa che quasi tutto il contenuto sia errato. La lettura non è quindi «34,6% di significato conservato» per la baseline 3B. La distanza fra media e mediana indica inoltre score molto eterogenei: la sola media non riassume bene tutti i casi. Le annotazioni indipendenti serviranno a distinguere errori reali e falsi allarmi.

La scelta è successiva alla lettura delle 126 fonti e precedente alla ricezione delle nuove annotazioni umane. Non è presentata come una preregistrazione del run già svolto. Gli score del metodo scelto sono stati estratti dai risultati contestuali già disponibili: tutte le 84 reference da annotare hanno lo score, senza altre inferenze. Le altre modalità restano secondarie e non viene applicata la soglia storica 0,04075 né introdotta una nuova soglia automatica di conservazione.

## La prova del giudice di naturalezza

Per la naturalezza è stato utilizzato tramite Groq il modello con identificativo `qwen/qwen3.8-27b`, con ragionamento disabilitato e risposta breve strutturata. Riceve due riscritture della stessa fonte, senza l'originale, e confronta formulazioni idiomatiche, registro, ritmo e coerenza linguistica. Non deve valutare evasione o fedeltà: sono aspetti misurati separatamente.

Ogni coppia viene presentata nei due ordini AB e BA. Una preferenza è stabile se il giudice sceglie lo stesso testo dopo lo scambio. Se sceglie sempre B, sta invece cambiando testo preferito. Questo controllo permette di distinguere una preferenza per la scrittura da una sensibilità alla posizione.

| Confronto | Risposte valide/attese | Coppie complete AB/BA | Preferenze stabili su 126 fonti |
|---|---:|---:|---:|
| Baseline 3B / 14B | 136/248 | 68 | 32/126 |
| Baseline 3B / DIPPER tre frasi | 128/246 | 64 | 46/126 |
| DIPPER passaggio / tre frasi | 100/250 | 50 | 15/126 |

: Copertura e stabilità dei confronti di naturalezza.

Le tre prove sono parziali. Le prime due esauriscono il budget di 256 tentativi ciascuna; la terza si ferma per un limite giornaliero di token, dopo 201 tentativi. Complessivamente risultano 364 risposte valide su 713 tentativi. Una prova preliminare sui sei casi dei pilot aggiunge 12 risposte e 12 tentativi, senza aggiungere nuove fonti.

Il limite non è soltanto la quota API. Fra le 182 coppie complete, 89 cambiano preferenza con l'ordine e 85 di queste scelgono B in entrambe le presentazioni. Non emerge quindi una graduatoria affidabile di naturalezza. Anche riportare soltanto i casi stabili sarebbe incompleto: la copertura sarebbe bassa e selezionata. La validazione preliminare con valutazioni dell'assistente è una concordanza fra strumenti AI, non una validazione umana.

Correggere il prompt su un insieme separato è una possibile fase di taratura. Richiede però preferenze umane: sapere che un testo è umano e l'altro macchina non stabilisce quale sia più naturale. Un secondo giudice di altra famiglia sarebbe un controllo utile, anche perché il giudice impiegato e i due riscrittori a prompt appartengono alla famiglia Qwen. Queste verifiche non sono ancora completate.

## Annotazioni in raccolta: verificare la conservazione

La verifica umana della conservazione parte da 84 coppie reference, già scelte senza usare gli score: 21 fonti e quattro riscritture per fonte. Le schede sono state distribuite a colleghi e, alla data di questa stesura, le annotazioni sono in raccolta. Non sono quindi disponibili risultati di accordo o di accuratezza rispetto ai lettori.

Ogni scheda mostra originale e riscrittura, senza nome del sistema o score. Il lettore indica il tipo di input e assegna `yes`, `partial` o `no` alla conservazione. `Yes` indica informazioni e forza delle affermazioni conservate; `partial` segnala cambiamenti rilevanti pur mantenendo il quadro principale; `no` indica un cambiamento ampio o l'esecuzione di un compito diverso. Vanno annotati anche tipo di errore e dettaglio che motiva il giudizio. Fondere frasi è ammesso se il contenuto rimane; accorciare non è di per sé un errore.

I giudizi dei lettori vengono mantenuti separati. Più annotatori migliorano la verifica, ma non aumentano il numero di fonti indipendenti. Per l'AUC principale è stata fissata prima della ricezione delle etichette la distinzione `yes` contro `partial/no`, mantenendo le tre classi nelle distribuzioni. I mancanti non diventano `yes`; gli eventuali disaccordi vanno discussi senza consultare gli score. La configurazione NLI non sarà ritoccata per massimizzare l'accordo sulle stesse schede.

Restano disponibili 99 coppie diagnostiche ulteriori, selezionate per approfondire casi difficili. Non vengono mescolate alle reference come se fossero un campione casuale. Il totale preparato è 183, non cento: 84 reference e 99 diagnostiche; il target di cento diagnostiche non è raggiunto perché la selezione mantiene interi i gruppi di fonte.

## Interpretazione complessiva dei risultati

Con questi preset, la stessa riscrittura può ridurre la rilevabilità su OpenAI e Binoculars e aumentarla su Fakespot. I controlli abbinati mostrano che il vantaggio dei sistemi a prompt non è riprodotto dal solo accorciamento. Per DIPPER sul detector storico non emerge invece un vantaggio aggregato chiaro rispetto al taglio.

Le misure di qualità richiedono una lettura distinta. Una similarità alta può convivere con errori di contenuto; l'NLI aggiunge un controllo informativo, ma dipende dalla premessa e può sia penalizzare fusioni corrette sia sostenere modifiche sbagliate. La calibrazione ha fissato una configurazione riproducibile. Le annotazioni distribuite ai colleghi serviranno a verificarla sui testi reali. Anche cambiare lo stile non dimostra automaticamente maggiore naturalezza: il giudice provato non è ancora abbastanza stabile per una graduatoria.

Queste conclusioni riguardano la riscrittura per parafrasi con quattro configurazioni fissate, su testi inglesi e generatori storici del corpus. Non descrivono tutti gli humanizer o i servizi commerciali. La valutazione umana in raccolta e la taratura del giudice rimangono i passaggi necessari prima di estendere ulteriormente il confronto.


## Come è organizzato il codice

Il codice segue lo stesso percorso degli esperimenti: prepara i dati, calcola le misure e analizza i risultati. Questa separazione permette di cambiare un'analisi senza riscrivere i testi o ripetere automaticamente l'esecuzione dei modelli. È particolarmente utile quando le inferenze richiedono una GPU o consumano una quota di API.

La struttura principale del repository è riassunta nella tabella seguente. I nomi delle cartelle identificano responsabilità diverse; non rappresentano esperimenti indipendenti da sommare.

| Cartella | Responsabilità | Esempio di contenuto |
|---|---|---|
| `stylometry/` | Preparazione e misure di stile | Pulizia, feature, abbinamento della lunghezza e classificazione |
| `semantics/` | Conservazione del significato | Perturbazioni, similarità, allineamenti, NLI e aggregazione |
| `humanizers/` | Studio delle riscritture | Selezione delle fonti, riscrittori, detector, controlli e giudice |
| `scripts/` | Comandi degli esperimenti | Preparazione, esecuzione delle misure e analisi dei file salvati |
| `kaggle/` | Esecuzione su GPU | Notebook, configurazioni e pacchetti dedicati |
| `results*` | Risultati leggibili e numerici | Tabelle, report, score per coppia e metadati |
| `exports/` | Materiali da trasferire | Archivi ricevuti e schede da annotare |
| `thesis/` | Documentazione scientifica | Questo capitolo, sorgenti LaTeX e sintesi per l'incontro |

: Organizzazione principale del repository.

### Dall'input alla tabella dei risultati

La preparazione assegna identificatori alla fonte e alla coppia di testi. Un file JSONL contiene un oggetto per riga: per una coppia sono registrati almeno identificativo, originale, trasformazione e metadati. Nello studio reale si aggiungono il riscrittore e lo stato dell'esecuzione. I file CSV contengono invece tabelle, come una riga di feature per testo oppure una riga di score per coppia. La distinzione fra identificativo della riscrittura e gruppo di fonte permette di collegare misure diverse senza perdere la dipendenza fra esempi dello stesso originale.

Gli script non hanno tutti lo stesso compito. Per esempio, `run_length_matched_style.py` prepara e analizza il confronto stilometrico a lunghezza abbinata; `run_humanizers.py` produce le riscritture; `run_detectors.py` e `run_zero_shot_detectors.py` applicano i detector. `score_contextual_nli.py` esegue le inferenze per i diversi contesti. `calibrate_contextual_nli.py` prepara il solo split di calibrazione e sceglie la configurazione da score già salvati. Questa distinzione rende controllabile il punto nel quale si generano nuovi dati e quello nel quale si rielaborano risultati esistenti.

La configurazione dello studio contiene modelli, revisioni dei pesi, istruzioni, limiti di ingresso e uscita, seed e condizioni attive. Il seed fissa i passaggi casuali del campionamento; la revisione identifica quale versione del checkpoint è stata usata. I metadati registrano anche il dispositivo e la precisione numerica. Le soglie dei detector e la scelta NLI vengono salvate separatamente dai testi, così una riscrittura non viene selezionata perché ottiene uno score favorevole.

### Esecuzione e riproducibilità

I primi esperimenti sono eseguiti nell'ambiente cloud con risorse limitate; la fase con riscrittori e detector più grandi usa Kaggle con due GPU Tesla T4. Le dipendenze per la GPU sono separate da quelle dell'ambiente CPU, mantenendo la versione CUDA di PyTorch fornita da Kaggle. I modelli vengono eseguiti in processi separati, in modo da liberare la memoria fra gli stadi. I pesi di DIPPER e del 14B sono caricati a quattro bit; il modello NLI rimane float32 e Binoculars mantiene i due Falcon in FP16 con statistiche FP32.

Le inferenze semantiche sono costose, perciò il programma conserva una cache, cioè un archivio dei confronti già calcolati. Una ripresa riusa gli score disponibili con la stessa configurazione, anziché rigenerare testi o azzerare i tentativi. Per il giudice vengono conservati anche i tentativi API non conclusi: il budget non riparte da zero dopo un'interruzione. Questo comportamento spiega perché un file finale possa contenere risultati parziali e perché lo stato del manifest debba essere letto insieme ai CSV.

Nel percorso CPU è stato inoltre usato un export ONNX del medesimo NLI base float32. Il confronto numerico con l'implementazione PyTorch ha verificato differenze dell'ordine di $10^{-6}$ sulle prove eseguite. Questa verifica riguarda la coerenza delle implementazioni, non l'accuratezza semantica del modello. Le inferenze contestuali dello studio e della calibrazione descritti qui usano il percorso PyTorch su GPU.

I controlli software verificano, fra l'altro, separazione delle fonti, denominatori, maschere di token, copertura dei testi, orientamento degli score e ripresa delle esecuzioni. I controlli sulle identità verificano anche che le differenze stilometriche siano nulle e le similarità prossime a uno. Un NLI identico non è invece imposto artificialmente a uno: il suo comportamento viene osservato e può rivelare un limite del modello. Questi controlli di programma non sostituiscono i giudizi umani.

Il repository pubblico contiene codice, configurazioni, tabelle e archivi condivisibili. I modelli e le cartelle locali di lavoro sono gestiti separatamente; non occorre includere un ambiente virtuale o decine di gigabyte di pesi per leggere un report. Le versioni archiviate e gli identificativi dei file permettono di distinguere i risultati originali dalle successive rielaborazioni. La documentazione indica i comandi pertinenti a ciascun esperimento, evitando che la riproduzione di un'analisi comporti involontariamente un nuovo run completo.[^repository]

[^repository]: Repository del progetto: <https://github.com/FrancescoM00/Humanization>. I report principali sono `REPORT_SPERIMENTALE.md`, `results_length_matched/report.md`, `results_semantic_fairness/interpretazione.md`, `results_kaggle_v2_study/report.md` e `results_nli_context_calibration/report.md`.

## Cosa è concluso e cosa rimane da verificare

Al momento di questa stesura sono disponibili l'analisi stilometrica con controllo della lunghezza, gli esperimenti semantici controllati, i pilot, lo studio sulle 126 fonti e la calibrazione della modalità NLI. La raccolta dei giudizi sulle 84 coppie reference è stata avviata coinvolgendo alcuni colleghi; le annotazioni non sono ancora state restituite e non vengono presentati risultati umani o valori di accordo.

Il passaggio successivo consiste nel confrontare la configurazione NLI già fissata con quelle etichette. Per la verifica principale della conservazione integrale, `yes` indica conservazione e `partial` o `no` indicano una modifica; le tre classi rimarranno comunque distinte nelle distribuzioni. I casi mancanti resteranno mancanti. Eventuali differenze fra lettori dovranno essere documentate e discusse senza scegliere il giudizio più favorevole alla metrica.

La naturalezza richiede un riferimento dedicato. Le annotazioni semantiche non sono voti sulla qualità della prosa; allo stesso modo, la provenienza umana o macchina non costituisce automaticamente una risposta corretta su quale testo sia più naturale. Prima di utilizzare il giudice per ordinare i riscrittori occorrerà verificarlo su preferenze umane esterne alla selezione dei sistemi, con controllo dell'ordine. Un confronto con un'altra famiglia di modelli potrà essere considerato come controllo secondario, se compatibile con il perimetro e il budget.

Rimane inoltre da definire la revisione statistica complessiva dei confronti fra detector: variazione del TPR, gestione dei quattro output mancanti e correzione dei confronti multipli. Una specifica scritta ora dovrà essere dichiarata successiva alla lettura dello studio, mantenendo distinti i risultati esplorativi dalle verifiche future. L'ampliamento del campione non sostituisce queste scelte: le 420 fonti, EditLens, Fast-DetectGPT e gli humanizer commerciali non sono stati eseguiti e rimangono fuori dai risultati del presente capitolo.
