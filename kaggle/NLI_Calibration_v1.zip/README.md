# Pacchetto NLI di calibrazione

[Guida Kaggle](https://raw.githubusercontent.com/FrancescoM00/Humanization/main/kaggle/README_NLI_Calibration.md). [Specifica](https://raw.githubusercontent.com/FrancescoM00/Humanization/main/NLI_CALIBRATION.md). Gli input congelati sono in inputs/; nessun checkpoint o etichetta umana nuova inclusi.
